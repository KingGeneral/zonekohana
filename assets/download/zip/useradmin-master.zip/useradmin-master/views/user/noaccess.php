<div class="block">
   <h1><?php echo __('Access denied'); ?></h1>
   <div class="content">
   <p><?php echo __('You do not have the necessary rights to access this functionality.'); ?></p>
   </div>
</div>

