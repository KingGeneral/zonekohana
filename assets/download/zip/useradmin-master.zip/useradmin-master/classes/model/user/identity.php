<?php defined('SYSPATH') or die('No direct access allowed.');

class Model_User_Identity extends Useradmin_Model_User_Identity { }