<?php defined('SYSPATH') or die('No direct access allowed.');

class Appform extends Useradmin_Appform { }