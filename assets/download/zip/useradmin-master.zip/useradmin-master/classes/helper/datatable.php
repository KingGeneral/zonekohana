<?php defined('SYSPATH') or die('No direct access allowed.');

class Helper_Datatable extends Useradmin_Helper_Datatable { }