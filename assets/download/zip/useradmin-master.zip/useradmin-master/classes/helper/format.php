<?php defined('SYSPATH') or die('No direct access allowed.');

class Helper_Format extends Useradmin_Helper_Format { }