<?php defined('SYSPATH') or die('No direct access allowed.');

class Provider_Twitter extends Useradmin_Provider_Twitter { }