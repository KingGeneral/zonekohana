<?php defined('SYSPATH') or die('No direct access allowed.');

class Provider_Facebook extends Useradmin_Provider_Facebook { }