<?php defined('SYSPATH') or die('No direct access allowed.');

abstract class Provider_OAuth extends Useradmin_Provider_OAuth { }