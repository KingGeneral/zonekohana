<?php defined('SYSPATH') or die('No direct access allowed.');

/**
 * User authorization library. Handles user login and logout, as well as secure
 * password hashing.
 *
 * @package    Useradmin/Auth
 * @author     Gabriel R. Giannattasio
 */
abstract class Auth extends Useradmin_Auth { }