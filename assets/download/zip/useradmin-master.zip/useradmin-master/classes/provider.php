<?php defined('SYSPATH') or die('No direct access allowed.');

abstract class Provider extends Useradmin_Provider { }