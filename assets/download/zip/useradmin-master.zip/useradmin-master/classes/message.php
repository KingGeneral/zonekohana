<?php defined('SYSPATH') or die('No direct access allowed.');

class Message extends Useradmin_Message { }