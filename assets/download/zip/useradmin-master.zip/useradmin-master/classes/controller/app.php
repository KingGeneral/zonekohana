<?php defined('SYSPATH') or die('No direct script access.');

class Controller_App extends Useradmin_Controller_App {}