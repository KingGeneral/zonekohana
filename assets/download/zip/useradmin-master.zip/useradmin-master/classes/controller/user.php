<?php defined('SYSPATH') or die('No direct script access.');

class Controller_User extends Useradmin_Controller_User {}