<?php defined('SYSPATH') or die('No direct script access.');

return array(
   'app_id'          => '',
   'api_key'         => '',
   'secret'          => '',
);
